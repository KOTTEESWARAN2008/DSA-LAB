QUIZNOVA - UPDATED ACCOUNT FLOW
1. Extract and copy Quiz_Practice_Portal to C:\XAMPPP\htdocs\
2. Start Apache and MySQL.
3. Import database.sql into phpMyAdmin. Database: quiz_practice_portal
4. Open http://localhost:8080/Quiz_Practice_Portal/

HOME PAGE: Two choices - Faculty Enter and Student Enter.
STUDENT: Student Enter -> Create a student account OR Already have an account (login).
FACULTY: Faculty Enter -> Create a faculty account OR Already have an account (login).
FACULTY CREATE: The registration route asks for the access password. Type SCSVMV; it is intentionally NOT displayed on the page. Then register faculty name, email, password and subject.
All existing test creation, publishing, shuffled MCQ, auto-scoring, notifications and result publication workflows are retained.
