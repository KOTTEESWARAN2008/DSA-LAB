QUIZNOVA - STUDENT ONLINE QUIZ AND PRACTICE PORTAL

INSTALLATION
1. Extract this ZIP.
2. Copy folder Quiz_Practice_Portal into C:\XAMPPP\htdocs\
   (Use your actual XAMPP htdocs folder if different.)
3. Start Apache and MySQL in XAMPP.
4. Open http://localhost:8080/phpmyadmin/
   If Apache uses port 80, use http://localhost/phpmyadmin/
5. Import database.sql. It creates database quiz_practice_portal.
6. Open http://localhost:8080/Quiz_Practice_Portal/
   For port 80: http://localhost/Quiz_Practice_Portal/

FACULTY
- On student login page click Faculty Enter (top-left).
- Enter initial faculty gate password SCSVMV.
- Register faculty name, email, password and subject.
- Return to login page and login with faculty email/password.
- Create a test, add MCQs and correct answers, save draft, then Publish test.

STUDENT
- Create account with name, email and password.
- Login, open a published test and submit answers.
- Score is calculated automatically but hidden from student until faculty clicks Publish result.
- Faculty receives an in-app notification on submission.
- Student receives an in-app notification when result is published.
- Student sees score, rank and performance history after publication.

NOTES
- config.php uses default XAMPP MySQL root with blank password. Change DB_PASS if needed.
- Questions and options are shuffled on each test attempt.
- One attempt per student per test.
- Rank is among students whose results are published for that test.
- Notifications appear in dashboards; no email/SMS/push notification is configured.
- Faculty gate password is a demo access gate, not production-grade security. Change it before real deployment.
- Timer is browser-side; this is a classroom project prototype, not a high-stakes exam platform.
