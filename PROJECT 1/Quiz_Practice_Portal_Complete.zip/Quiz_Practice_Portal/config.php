<?php
session_start();
define('DB_HOST','localhost'); define('DB_NAME','quiz_practice_portal'); define('DB_USER','root'); define('DB_PASS','');
function db(){static $p=null;if(!$p)$p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);return $p;}
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function go($u){header("Location: $u");exit;}
function flash($m,$t='success'){$_SESSION['flash']=[$m,$t];}
function show_flash(){if(isset($_SESSION['flash'])){[$m,$t]=$_SESSION['flash'];unset($_SESSION['flash']);echo '<div class="toast '.h($t).'">'.h($m).'</div>';}}
function need($r){if(empty($_SESSION['user_id'])||$_SESSION['role']!==$r)go('index.php');}
function notice($uid,$msg){$s=db()->prepare("INSERT INTO notifications(user_id,message) VALUES(?,?)");$s->execute([$uid,$msg]);}
