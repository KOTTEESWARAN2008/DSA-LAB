STUDYFLOW - Smart Student Timetable and Reminder System

REQUIREMENTS
- XAMPP (Apache + MySQL)
- PHP 8+ recommended (PDO MySQL extension enabled)
- Browser

INSTALLATION (Windows / XAMPP)
1. Extract StudyFlow.zip.
2. Copy the StudyFlow folder into C:\xampp\htdocs\
3. Open XAMPP Control Panel and start Apache and MySQL.
4. Open http://localhost/phpmyadmin
5. Choose Import, select StudyFlow\database.sql, and click Import.
6. Open config.php. Default XAMPP settings are:
   database = studyflow, username = root, password = empty.
   Change these values if your MySQL setup is different.
7. Open http://localhost/StudyFlow/register.php
8. Create a student account and sign in.

FEATURES
- Student registration and login (passwords are hashed)
- Subject add/edit/delete
- Daily and weekly timetable; add/edit/delete periods
- Assignment and examination reminders
- Mark reminders complete / undo
- Personal study planner; mark tasks complete / undo
- Dashboard summaries and today's class list
- Each student's records are restricted to their own account

IMPORTANT
- Add subjects first, then create timetable periods.
- This starter project uses PDO prepared statements.
- Reminder dates are displayed in the app. Browser notifications/email alerts
  are not included in this version.
- For a real deployment, add CSRF protection, stricter validation, HTTPS,
  and role-based faculty access.
