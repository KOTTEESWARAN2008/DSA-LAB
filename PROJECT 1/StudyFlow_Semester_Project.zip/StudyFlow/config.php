<?php
session_start();

$host = 'localhost';
$db   = 'studyflow';
$user = 'root';
$pass = ''; // Change if your MySQL has a password.

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    exit('Database connection failed. Check config.php and import database.sql.');
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function logged_in() {
    return isset($_SESSION['user_id']);
}
function require_login() {
    if (!logged_in()) {
        header('Location: login.php');
        exit;
    }
}
