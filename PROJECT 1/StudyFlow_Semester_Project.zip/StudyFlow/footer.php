<div class="footerhint">StudyFlow · Your personal academic planner</div>
</main></div>
