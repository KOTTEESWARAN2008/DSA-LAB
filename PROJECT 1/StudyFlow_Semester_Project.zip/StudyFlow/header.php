<?php
require_once 'config.php';
require_login();
$page = basename($_SERVER['PHP_SELF']);
?>
<div class="shell">
<aside class="sidebar">
  <div class="brand">study<span>flow</span>.</div>
  <div class="navlabel">WORKSPACE</div>
  <nav class="nav">
    <a class="<?= $page==='index.php'?'active':'' ?>" href="index.php">◈ Dashboard</a>
    <a class="<?= $page==='subjects.php'?'active':'' ?>" href="subjects.php">▦ Subjects</a>
    <a class="<?= $page==='timetable.php'?'active':'' ?>" href="timetable.php">▤ Timetable</a>
    <a class="<?= $page==='reminders.php'?'active':'' ?>" href="reminders.php">◷ Reminders</a>
    <a class="<?= $page==='planner.php'?'active':'' ?>" href="planner.php">✦ Study planner</a>
  </nav>
  <div class="navlabel">ACCOUNT</div>
  <nav class="nav"><a href="logout.php">↪ Logout</a></nav>
</aside>
<main class="main">
<header class="top">
  <div><small>STUDENT WORKSPACE</small><h1><?= h(ucfirst(str_replace('.php','',$page))) ?></h1><div class="welcome">Plan smarter. Learn better.</div></div>
  <div class="userpill">● <?= h($_SESSION['user_name']) ?></div>
</header>
