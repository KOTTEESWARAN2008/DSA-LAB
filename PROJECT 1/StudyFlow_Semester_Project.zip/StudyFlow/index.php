<?php
require 'config.php'; require_login();
$uid=$_SESSION['user_id'];
$q=$pdo->prepare("SELECT COUNT(*) FROM timetable WHERE user_id=?");$q->execute([$uid]);$periods=$q->fetchColumn();
$q=$pdo->prepare("SELECT COUNT(*) FROM subjects WHERE user_id=?");$q->execute([$uid]);$subjects=$q->fetchColumn();
$q=$pdo->prepare("SELECT COUNT(*) FROM reminders WHERE user_id=? AND is_done=0 AND due_date>=CURDATE()");$q->execute([$uid]);$reminders=$q->fetchColumn();
$q=$pdo->prepare("SELECT COUNT(*) FROM study_plans WHERE user_id=? AND is_done=0 AND plan_date=CURDATE()");$q->execute([$uid]);$plans=$q->fetchColumn();
$q=$pdo->prepare("SELECT t.*,s.subject_name,s.color FROM timetable t JOIN subjects s ON s.id=t.subject_id WHERE t.user_id=? AND t.day_name=? ORDER BY t.start_time");
$q->execute([$uid,date('l')]);$today=$q->fetchAll();
$q=$pdo->prepare("SELECT r.*,s.subject_name FROM reminders r LEFT JOIN subjects s ON s.id=r.subject_id WHERE r.user_id=? AND r.is_done=0 AND r.due_date>=CURDATE() ORDER BY r.due_date,r.due_time LIMIT 5");$q->execute([$uid]);$upcoming=$q->fetchAll();
require 'header.php';
?>
<div class="grid">
 <div class="card"><div class="statlabel">Subjects</div><div class="stat"><?=$subjects?></div><span class="tag">Your courses</span></div>
 <div class="card"><div class="statlabel">Timetable periods</div><div class="stat"><?=$periods?></div><span class="tag">Weekly schedule</span></div>
 <div class="card"><div class="statlabel">Upcoming reminders</div><div class="stat"><?=$reminders?></div><span class="tag">Assignments + exams</span></div>
 <div class="card"><div class="statlabel">Study tasks today</div><div class="stat"><?=$plans?></div><span class="tag">Personal planner</span></div>
</div>
<div class="two">
 <section class="panel"><div class="panelhead"><div><h2>Today's timetable</h2><small class="muted"><?=date('l, d M Y')?></small></div><a class="btn small" href="timetable.php">Manage</a></div>
 <?php if(!$today):?><div class="empty">No periods added for today. Add your weekly schedule.</div><?php else: foreach($today as $t):?>
 <div class="item"><div><strong><?=h($t['subject_name'])?></strong><div class="muted"><?=h(substr($t['start_time'],0,5))?> – <?=h(substr($t['end_time'],0,5))?> · <?=h($t['room'])?></div></div><span class="tag">Class</span></div>
 <?php endforeach; endif;?></section>
 <section class="panel"><div class="panelhead"><h2>Coming up</h2><a href="reminders.php" class="btn small secondary">View all</a></div>
 <?php if(!$upcoming):?><div class="empty">No upcoming reminders.</div><?php else:foreach($upcoming as $r):?>
 <div class="item"><div><strong><?=h($r['title'])?></strong><div class="muted"><?=h($r['reminder_type'])?> · <?=date('d M',strtotime($r['due_date']))?></div></div><span class="tag"><?=h($r['subject_name']??'General')?></span></div>
 <?php endforeach;endif;?></section>
</div>
<?php require 'footer.php'; ?>
