<?php
require 'config.php';
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $s=$pdo->prepare('SELECT * FROM users WHERE email=?'); $s->execute([trim($_POST['email']??'')]); $u=$s->fetch();
  if($u && password_verify($_POST['password']??'',$u['password'])) {
    session_regenerate_id(true); $_SESSION['user_id']=$u['id']; $_SESSION['user_name']=$u['name']; header('Location: index.php'); exit;
  } else $error='Incorrect email or password.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login · StudyFlow</title><link rel="stylesheet" href="style.css"></head><body>
<div class="panel auth"><div class="brand">study<span>flow</span>.</div><h1>Welcome back</h1><p>Sign in to view your timetable and reminders.</p>
<?php if(isset($_GET['registered'])):?><div class="notice">Account created. Please sign in.</div><?php endif;?>
<?php if($error):?><div class="notice"><?=h($error)?></div><?php endif;?>
<form method="post"><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password</label><input type="password" name="password" required></div><button class="btn">Sign in</button></form><p>New student? <a href="register.php">Create an account</a></p></div></body></html>
