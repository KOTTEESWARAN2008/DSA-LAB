<?php
require 'config.php';require_login();$uid=$_SESSION['user_id'];
if(isset($_GET['done'])){$s=$pdo->prepare('UPDATE study_plans SET is_done=1-is_done WHERE id=? AND user_id=?');$s->execute([(int)$_GET['done'],$uid]);header('Location: planner.php');exit;}
if(isset($_GET['delete'])){$s=$pdo->prepare('DELETE FROM study_plans WHERE id=? AND user_id=?');$s->execute([(int)$_GET['delete'],$uid]);header('Location: planner.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $title=trim($_POST['title']??'');$date=$_POST['plan_date']??'';$start=$_POST['start_time']?:null;$end=$_POST['end_time']?:null;$notes=trim($_POST['notes']??'');
 if($title===''||!$date||($start&&$end&&$end<=$start))$error='Enter a task, date and valid time range.';
 else{$s=$pdo->prepare('INSERT INTO study_plans(user_id,title,plan_date,start_time,end_time,notes) VALUES(?,?,?,?,?,?)');$s->execute([$uid,$title,$date,$start,$end,$notes]);header('Location: planner.php');exit;}
}
$s=$pdo->prepare('SELECT * FROM study_plans WHERE user_id=? ORDER BY plan_date,start_time');$s->execute([$uid]);$rows=$s->fetchAll();
require 'header.php';?>
<?php if($error):?><div class="notice"><?=h($error)?></div><?php endif;?>
<div class="two"><section class="panel"><h2>Plan a study session</h2><form method="post"><div class="field"><label>Study goal / task</label><input name="title" placeholder="e.g. Revise Java collections" required></div><div class="field"><label>Date</label><input type="date" name="plan_date" min="<?=date('Y-m-d')?>" value="<?=date('Y-m-d')?>" required></div><div class="formgrid"><div class="field"><label>Start time</label><input type="time" name="start_time"></div><div class="field"><label>End time</label><input type="time" name="end_time"></div></div><div class="field"><label>Notes</label><textarea name="notes" placeholder="Topics to cover..."></textarea></div><button class="btn">Add study plan</button></form></section>
<section class="panel"><h2>Your study planner</h2><?php if(!$rows):?><div class="empty">No study sessions planned yet.</div><?php else:foreach($rows as $r):?><div class="item"><div><strong style="<?=$r['is_done']?'text-decoration:line-through;opacity:.6':''?>"><?=h($r['title'])?></strong><div class="muted"><?=date('d M Y',strtotime($r['plan_date']))?> · <?=h($r['start_time']?substr($r['start_time'],0,5):'Time not set')?><?= $r['end_time']?' – '.h(substr($r['end_time'],0,5)):''?></div><?php if($r['notes']):?><small class="muted"><?=h($r['notes'])?></small><?php endif;?></div><div class="actions"><a class="btn small secondary" href="?done=<?=$r['id']?>"><?=$r['is_done']?'Undo':'Done'?></a><a class="btn small danger" onclick="return confirm('Delete study plan?')" href="?delete=<?=$r['id']?>">×</a></div></div><?php endforeach;endif;?></section></div>
<?php require 'footer.php';?>
