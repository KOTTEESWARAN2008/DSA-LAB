<?php
require 'config.php';
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $name=trim($_POST['name']??''); $email=trim($_POST['email']??''); $password=$_POST['password']??'';
  if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<6) $error='Enter a name, valid email and password (at least 6 characters).';
  else {
    try {
      $s=$pdo->prepare('INSERT INTO users(name,email,password) VALUES(?,?,?)');
      $s->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
      header('Location: login.php?registered=1'); exit;
    } catch(PDOException $e) {$error='This email may already be registered.';}
  }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Register · StudyFlow</title><link rel="stylesheet" href="style.css"></head><body>
<div class="panel auth"><div class="brand">study<span>flow</span>.</div><h1>Create account</h1><p>Start organising your academic week.</p><?php if($error):?><div class="notice"><?=h($error)?></div><?php endif;?>
<form method="post"><div class="field"><label>Full name</label><input name="name" required></div><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password (minimum 6 characters)</label><input type="password" name="password" minlength="6" required></div><button class="btn">Create account</button></form><p>Already registered? <a href="login.php">Sign in</a></p></div></body></html>
