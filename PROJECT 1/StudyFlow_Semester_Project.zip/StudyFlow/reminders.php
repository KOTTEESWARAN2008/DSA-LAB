<?php
require 'config.php';require_login();$uid=$_SESSION['user_id'];
if(isset($_GET['done'])){$s=$pdo->prepare('UPDATE reminders SET is_done=1-is_done WHERE id=? AND user_id=?');$s->execute([(int)$_GET['done'],$uid]);header('Location: reminders.php');exit;}
if(isset($_GET['delete'])){$s=$pdo->prepare('DELETE FROM reminders WHERE id=? AND user_id=?');$s->execute([(int)$_GET['delete'],$uid]);header('Location: reminders.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $type=$_POST['reminder_type']??'';$title=trim($_POST['title']??'');$sid=$_POST['subject_id']!==''?(int)$_POST['subject_id']:null;$date=$_POST['due_date']??'';$time=$_POST['due_time']?:null;$notes=trim($_POST['notes']??'');
 if(!in_array($type,['Assignment','Exam'],true)||$title===''||!$date)$error='Enter reminder type, title and due date.';
 else{$s=$pdo->prepare('INSERT INTO reminders(user_id,reminder_type,title,subject_id,due_date,due_time,notes) VALUES(?,?,?,?,?,?,?)');$s->execute([$uid,$type,$title,$sid,$date,$time,$notes]);header('Location: reminders.php');exit;}
}
$s=$pdo->prepare('SELECT * FROM subjects WHERE user_id=? ORDER BY subject_name');$s->execute([$uid]);$subjects=$s->fetchAll();
$s=$pdo->prepare('SELECT r.*,s.subject_name FROM reminders r LEFT JOIN subjects s ON s.id=r.subject_id WHERE r.user_id=? ORDER BY r.is_done,r.due_date,r.due_time');$s->execute([$uid]);$rows=$s->fetchAll();
require 'header.php';?>
<?php if($error):?><div class="notice"><?=h($error)?></div><?php endif;?>
<div class="two"><section class="panel"><h2>Create a reminder</h2><form method="post"><div class="field"><label>Reminder type</label><select name="reminder_type"><option>Assignment</option><option>Exam</option></select></div><div class="field"><label>Title</label><input name="title" placeholder="e.g. DBMS Unit 2 assignment" required></div><div class="field"><label>Subject (optional)</label><select name="subject_id"><option value="">General</option><?php foreach($subjects as $sub):?><option value="<?=$sub['id']?>"><?=h($sub['subject_name'])?></option><?php endforeach;?></select></div><div class="formgrid"><div class="field"><label>Due date</label><input type="date" name="due_date" min="<?=date('Y-m-d')?>" required></div><div class="field"><label>Time (optional)</label><input type="time" name="due_time"></div></div><div class="field"><label>Notes</label><textarea name="notes"></textarea></div><button class="btn">Save reminder</button></form></section>
<section class="panel"><h2>Assignment & exam reminders</h2><?php if(!$rows):?><div class="empty">No reminders added yet.</div><?php else:foreach($rows as $r):?><div class="item"><div><strong style="<?=$r['is_done']?'text-decoration:line-through;opacity:.6':''?>"><?=h($r['title'])?></strong><div class="muted"><?=h($r['reminder_type'])?> · <?=h($r['subject_name']??'General')?> · <?=date('d M Y',strtotime($r['due_date']))?> <?=h($r['due_time']?substr($r['due_time'],0,5):'')?></div><?php if($r['notes']):?><small class="muted"><?=h($r['notes'])?></small><?php endif;?></div><div class="actions"><a class="btn small secondary" href="?done=<?=$r['id']?>"><?=$r['is_done']?'Undo':'Done'?></a><a class="btn small danger" onclick="return confirm('Delete reminder?')" href="?delete=<?=$r['id']?>">×</a></div></div><?php endforeach;endif;?></section></div>
<?php require 'footer.php';?>
