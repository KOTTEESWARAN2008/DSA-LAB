<?php
require 'config.php';require_login();$uid=$_SESSION['user_id'];
if(isset($_GET['delete'])){$s=$pdo->prepare('DELETE FROM subjects WHERE id=? AND user_id=?');$s->execute([(int)$_GET['delete'],$uid]);header('Location: subjects.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $id=(int)($_POST['id']??0);$name=trim($_POST['subject_name']??'');$code=trim($_POST['subject_code']??'');$faculty=trim($_POST['faculty']??'');$color=$_POST['color']??'#7c3aed';
 if($name==='')$error='Subject name is required.';
 else if($id){$s=$pdo->prepare('UPDATE subjects SET subject_name=?,subject_code=?,faculty=?,color=? WHERE id=? AND user_id=?');$s->execute([$name,$code,$faculty,$color,$id,$uid]);}
 else{$s=$pdo->prepare('INSERT INTO subjects(user_id,subject_name,subject_code,faculty,color) VALUES(?,?,?,?,?)');$s->execute([$uid,$name,$code,$faculty,$color]);}
 if(!$error){header('Location: subjects.php');exit;}
}
$edit=null;if(isset($_GET['edit'])){$s=$pdo->prepare('SELECT * FROM subjects WHERE id=? AND user_id=?');$s->execute([(int)$_GET['edit'],$uid]);$edit=$s->fetch();}
$s=$pdo->prepare('SELECT * FROM subjects WHERE user_id=? ORDER BY subject_name');$s->execute([$uid]);$rows=$s->fetchAll();
require 'header.php';?>
<?php if($error):?><div class="notice"><?=h($error)?></div><?php endif;?>
<div class="two"><section class="panel"><h2><?= $edit?'Edit subject':'Add a subject' ?></h2><form method="post"><input type="hidden" name="id" value="<?=h($edit['id']??'')?>"><div class="field"><label>Subject name</label><input name="subject_name" required value="<?=h($edit['subject_name']??'')?>"></div><div class="formgrid"><div class="field"><label>Subject code</label><input name="subject_code" value="<?=h($edit['subject_code']??'')?>"></div><div class="field"><label>Faculty</label><input name="faculty" value="<?=h($edit['faculty']??'')?>"></div></div><div class="field"><label>Subject colour</label><input type="color" name="color" value="<?=h($edit['color']??'#7c3aed')?>"></div><button class="btn">Save subject</button></form></section>
<section class="panel"><h2>Your subjects</h2><?php if(!$rows):?><div class="empty">No subjects yet. Add your first subject.</div><?php else:foreach($rows as $r):?><div class="item"><div><strong><?=h($r['subject_name'])?></strong><div class="muted"><?=h($r['subject_code'])?> · <?=h($r['faculty'])?></div></div><div class="actions"><a class="btn small secondary" href="?edit=<?=$r['id']?>">Edit</a><a class="btn small danger" onclick="return confirm('Delete this subject and its linked timetable periods?')" href="?delete=<?=$r['id']?>">Delete</a></div></div><?php endforeach;endif;?></section></div>
<?php require 'footer.php';?>
