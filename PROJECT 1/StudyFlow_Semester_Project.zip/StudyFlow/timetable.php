<?php
require 'config.php';require_login();$uid=$_SESSION['user_id'];
$days=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
if(isset($_GET['delete'])){$s=$pdo->prepare('DELETE FROM timetable WHERE id=? AND user_id=?');$s->execute([(int)$_GET['delete'],$uid]);header('Location: timetable.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $id=(int)($_POST['id']??0);$sid=(int)($_POST['subject_id']??0);$day=$_POST['day_name']??'';$start=$_POST['start_time']??'';$end=$_POST['end_time']??'';$room=trim($_POST['room']??'');
 if(!$sid || !in_array($day,$days,true) || !$start || !$end || $end<=$start)$error='Choose a subject and valid period times (end must be after start).';
 else{
  $chk=$pdo->prepare('SELECT id FROM subjects WHERE id=? AND user_id=?');$chk->execute([$sid,$uid]);
  if(!$chk->fetch())$error='Invalid subject selected.';
  else if($id){$s=$pdo->prepare('UPDATE timetable SET subject_id=?,day_name=?,start_time=?,end_time=?,room=? WHERE id=? AND user_id=?');$s->execute([$sid,$day,$start,$end,$room,$id,$uid]);}
  else{$s=$pdo->prepare('INSERT INTO timetable(user_id,subject_id,day_name,start_time,end_time,room) VALUES(?,?,?,?,?,?)');$s->execute([$uid,$sid,$day,$start,$end,$room]);}
  if(!$error){header('Location: timetable.php?day='.urlencode($day));exit;}
 }
}
$subjects=$pdo->prepare('SELECT * FROM subjects WHERE user_id=? ORDER BY subject_name');$subjects->execute([$uid]);$subjects=$subjects->fetchAll();
$selected=$_GET['day']??date('l');if(!in_array($selected,$days,true))$selected='Monday';
$edit=null;if(isset($_GET['edit'])){$s=$pdo->prepare('SELECT * FROM timetable WHERE id=? AND user_id=?');$s->execute([(int)$_GET['edit'],$uid]);$edit=$s->fetch();}
$s=$pdo->prepare('SELECT t.*,s.subject_name,s.color FROM timetable t JOIN subjects s ON s.id=t.subject_id WHERE t.user_id=? AND t.day_name=? ORDER BY t.start_time');$s->execute([$uid,$selected]);$rows=$s->fetchAll();
require 'header.php';?>
<?php if($error):?><div class="notice"><?=h($error)?></div><?php endif;?>
<div class="panel" style="margin-bottom:18px"><div class="panelhead"><h2>Weekly timetable</h2><span class="muted">Select a day to view periods</span></div><div class="days"><?php foreach($days as $d):?><a class="<?=$selected===$d?'active':''?>" href="?day=<?=$d?>"><?=substr($d,0,3)?></a><?php endforeach;?></div><h3><?=h($selected)?></h3>
<?php if(!$rows):?><div class="empty">No periods for <?=h($selected)?> yet.</div><?php else:?><div class="tablewrap"><table><thead><tr><th>Time</th><th>Subject</th><th>Room</th><th>Action</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=h(substr($r['start_time'],0,5))?> – <?=h(substr($r['end_time'],0,5))?></td><td><span class="tag" style="border-left:4px solid <?=h($r['color'])?>"><?=h($r['subject_name'])?></span></td><td><?=h($r['room'])?></td><td class="actions"><a class="btn small secondary" href="?day=<?=$selected?>&edit=<?=$r['id']?>">Edit</a><a class="btn small danger" onclick="return confirm('Delete this period?')" href="?day=<?=$selected?>&delete=<?=$r['id']?>">Delete</a></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></div>
<div class="panel"><h2><?= $edit?'Edit period':'Add a period' ?></h2><?php if(!$subjects):?><div class="notice">Add a subject first in the Subjects page.</div><?php else:?><form method="post"><input type="hidden" name="id" value="<?=h($edit['id']??'')?>"><div class="formgrid"><div class="field"><label>Subject</label><select name="subject_id" required><?php foreach($subjects as $sub):?><option value="<?=$sub['id']?>" <?=($edit['subject_id']??'')==$sub['id']?'selected':''?>><?=h($sub['subject_name'])?></option><?php endforeach;?></select></div><div class="field"><label>Day</label><select name="day_name"><?php foreach($days as $d):?><option <?=($edit['day_name']??$selected)===$d?'selected':''?>><?=$d?></option><?php endforeach;?></select></div><div class="field"><label>Start time</label><input type="time" name="start_time" required value="<?=h(isset($edit['start_time'])?substr($edit['start_time'],0,5):'09:00')?>"></div><div class="field"><label>End time</label><input type="time" name="end_time" required value="<?=h(isset($edit['end_time'])?substr($edit['end_time'],0,5):'10:00')?>"></div><div class="field"><label>Room / Location</label><input name="room" value="<?=h($edit['room']??'')?>"></div></div><button class="btn">Save period</button></form><?php endif;?></div>
<?php require 'footer.php';?>
