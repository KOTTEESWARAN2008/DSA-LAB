SUBMITLY — ASSIGNMENT SUBMISSION PORTAL (PHP + MYSQL)
=====================================================

THIS VERSION
- Premium redesigned entry page with separate Faculty Enter and Student Enter cards.
- Faculty and Student access pages have matching visual styling.
- Existing assignment workflow and database logic are preserved.

WORKFLOW (UNCHANGED)
1. Faculty creates an account after faculty access verification, or signs in.
2. Faculty publishes an assignment with title, subject, instructions and deadline.
3. Student creates an account or signs in, views assignments and uploads PDF, DOC or DOCX work before the deadline.
4. Faculty receives an in-app notification when a student submits.
5. Faculty downloads and reviews the submission, enters marks and remarks, and publishes feedback.
6. Student receives an in-app notification and can view marks and remarks.

ACCOUNT SECURITY
- Faculty registration is protected by the faculty access password SCSVMV. The code is not displayed on the page.
- Student registration is separate from faculty registration.
- Registration has Password and Confirm Password fields with eye controls to show/hide each password.
- Passwords are hashed; minimum 8 characters; confirmation is checked on the server.
- Faculty and student login pages only accept the matching account role.

INSTALL IN XAMPP (WINDOWS)
1. Extract this ZIP file.
2. Copy Assignment_Submission_Portal into C:\XAMPPP\htdocs\
3. Start Apache and MySQL in XAMPP Control Panel.
4. Open http://localhost:8080/phpmyadmin/
5. Import database.sql. It creates assignment_portal and its tables. Use a fresh database or back up any existing data first.
6. If MySQL root password is not blank, update config.php.
7. Open http://localhost:8080/Assignment_Submission_Portal/

NOTES
- Notifications are in-app only, not email/SMS/push.
- Uploads: PDF / DOC / DOCX, maximum 10 MB.
- Keep Apache, MySQL and the host computer running for classroom/LAN use.
- Use HTTPS and secure credentials before public hosting. Never expose XAMPP/phpMyAdmin directly to the public internet.
