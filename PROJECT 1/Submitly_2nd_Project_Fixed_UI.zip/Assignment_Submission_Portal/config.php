<?php
session_start();
$pdo=new PDO('mysql:host=localhost;dbname=assignment_portal;charset=utf8mb4','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function go($p){header("Location: index.php?page=$p");exit;}
function need($role=null){if(empty($_SESSION['user']))go('login');if($role && $_SESSION['user']['role']!==$role){http_response_code(403);exit('Access denied');}}
function token(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));return $_SESSION['csrf'];}
function check(){if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??''))exit('Invalid request');}
function msg($s){$_SESSION['msg']=$s;}
