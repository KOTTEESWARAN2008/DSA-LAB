<?php
require 'config.php';
if(empty($_SESSION['user'])||$_SESSION['user']['role']!=='faculty')exit('Access denied');
$id=(int)($_GET['id']??0);$q=$pdo->prepare('SELECT s.*,a.faculty_id FROM submissions s JOIN assignments a ON a.id=s.assignment_id WHERE s.id=? AND a.faculty_id=?');$q->execute([$id,$_SESSION['user']['id']]);$s=$q->fetch();if(!$s)exit('Not found');$p=__DIR__.'/uploads/'.$s['stored_name'];if(!is_file($p))exit('File missing');header('Content-Type: application/octet-stream');header('Content-Disposition: attachment; filename="'.str_replace('"','',basename($s['original_name'])).'"');header('Content-Length: '.filesize($p));readfile($p);
