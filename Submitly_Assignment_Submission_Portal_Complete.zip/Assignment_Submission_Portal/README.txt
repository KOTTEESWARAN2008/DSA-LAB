SUBMITLY — ASSIGNMENT SUBMISSION PORTAL (PHP + MYSQL)
=====================================================

FEATURES INCLUDED
- Student and faculty accounts (new registrations are students)
- Faculty can create assignments with title, subject, instructions and exact deadline date/time
- Student assignment board with open/closed deadline status
- PDF, DOC and DOCX uploads (maximum 10 MB)
- Faculty can download submitted files
- Students can submit a newer version before the deadline
- Submission history and current submission status
- Faculty can enter marks awarded, maximum marks and written remarks
- Student sees marks and automatically calculated percentage
- In-app notifications when a student submits and when faculty publishes marks/remarks
- Responsive dashboard and premium Submitly interface

INSTALL IN XAMPP (WINDOWS)
1. Extract this ZIP file.
2. Copy the folder Assignment_Submission_Portal into C:\XAMPPP\htdocs\
   (use your actual XAMPP htdocs folder if different).
3. Open XAMPP Control Panel and start Apache and MySQL.
4. Open http://localhost:8080/phpmyadmin/
   If Apache uses port 80, use http://localhost/phpmyadmin/ instead.
5. Create/import the database: select Import, choose database.sql from this folder,
   then click Import/Go. The SQL creates assignment_portal and its tables.
6. If your MySQL root password is not blank, edit config.php and update the password.
7. Open http://localhost:8080/Assignment_Submission_Portal/

CREATE A FACULTY ACCOUNT
1. Register in the website using the faculty email address.
2. Open phpMyAdmin > assignment_portal > SQL and run this query,
   replacing the email with the account you registered:
   UPDATE users SET role='faculty' WHERE email='faculty@example.com';
3. Sign out and sign in again. The Faculty workspace will appear.

FRIENDS ON THE SAME WI-FI
1. On the computer running XAMPP, open Command Prompt and type: ipconfig
2. Find the IPv4 Address of the Wi-Fi adapter (example: 192.168.1.5).
3. Allow Apache / TCP port 8080 through Windows Defender Firewall on Private networks.
4. Your friends open this URL on the same Wi-Fi:
   http://192.168.1.5:8080/Assignment_Submission_Portal/
   Replace 192.168.1.5 with your computer's actual IPv4 address.
5. Keep your computer, Apache and MySQL running while they use the portal.

UPLOAD SETTINGS
The app accepts PDF/DOC/DOCX up to 10 MB. If uploads fail, open the active php.ini
from XAMPP Control Panel > Apache > Config > PHP (php.ini), set:
  upload_max_filesize=10M
  post_max_size=12M
  max_file_uploads=20
Save and restart Apache. Ensure the uploads folder is writable.

IMPORTANT
- Notifications are stored in the portal and shown in the Notifications page; they are
  not email, SMS or mobile push notifications.
- Deadline checks use the web server's local timezone.
- This package is intended for local/LAN classroom use. For access from anywhere,
  deploy it to a PHP + MySQL hosting provider and use HTTPS.
- Do not expose XAMPP/phpMyAdmin directly to the public internet.
- Change database credentials and use HTTPS before any public deployment.
- Import this database.sql into a fresh assignment_portal database. Back up any existing
  project database before replacing it.
